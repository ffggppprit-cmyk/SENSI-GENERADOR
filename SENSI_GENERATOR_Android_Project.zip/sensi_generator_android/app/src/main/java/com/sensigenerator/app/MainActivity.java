package com.sensigenerator.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(16,16,24);
    private final int PANEL = Color.rgb( thirty(), 29, 41);
    private final int RED = Color.rgb(255,64,87);
    private final int WHITE = Color.rgb(248,247,252);
    private final int MUTED = Color.rgb(180,176,194);
    private final String[] labels = {"Geral", "Ponto Vermelho", "Mira 2x", "Mira 4x", "Mira AWM", "Olhadinha"};
    private final int[] defaults = {185,178,168,150,85,140};
    private final int[] values = {185,178,168,150,85,140};
    private Spinner brandSpinner, modelSpinner, styleSpinner, scaleSpinner, dpiSpinner;
    private LinearLayout root, valueList;
    private TextView profileText;

    private static int thirty() { return 36; }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        buildUi();
    }

    private GradientDrawable bg(int color, int radius, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius * getResources().getDisplayMetrics().density);
        if (strokeColor != 0) d.setStroke((int)(1 * getResources().getDisplayMetrics().density), strokeColor);
        return d;
    }

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        return t;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w < 0 ? w : dp(w), h < 0 ? h : dp(h));
    }

    private void addGap(LinearLayout parent, int h) {
        View v = new View(this); parent.addView(v, lp(1,h));
    }

    private TextView heading(String title) {
        TextView t = text(title, 15, WHITE, true);
        t.setPadding(0, dp(8), 0, dp(8));
        return t;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        root = column();
        root.setPadding(dp(18), dp(18), dp(18), dp(24));
        scroll.addView(root);
        setContentView(scroll);

        LinearLayout hero = column();
        hero.setPadding(dp(18), dp(20), dp(18), dp(20));
        hero.setBackground(bg(Color.rgb(31,20,35), 22, Color.rgb(90,39,57)));
        root.addView(hero, lp(-1,-2));

        TextView eyebrow = text("FREE FIRE  •  MOBILE", 11, RED, true);
        hero.addView(eyebrow);
        addGap(hero, 6);
        TextView title = text("SENSI GENERATOR", 25, WHITE, true);
        hero.addView(title);
        addGap(hero, 5);
        hero.addView(text("Monte sua configuração e ajuste os valores ao seu estilo.", 13, MUTED, false));
        addGap(hero, 14);
        TextView chip = text("●  GERADOR DEMONSTRATIVO", 11, WHITE, true);
        chip.setPadding(dp(10), dp(8), dp(10), dp(8));
        chip.setBackground(bg(Color.rgb(63,28,42), 18, RED));
        hero.addView(chip, lp(-2,-2));

        addGap(root, 18);
        root.addView(heading("01  •  SEU DISPOSITIVO"));
        LinearLayout deviceCard = column();
        deviceCard.setPadding(dp(14), dp(6), dp(14), dp(12));
        deviceCard.setBackground(bg(PANEL, 18, Color.rgb(60,54,72)));
        root.addView(deviceCard, lp(-1,-2));

        deviceCard.addView(text("Marca", 12, MUTED, true));
        brandSpinner = spinner(new String[]{"Samsung","Motorola","Xiaomi / Redmi / POCO","Apple iPhone","Realme","OPPO","Vivo","Outra marca"});
        deviceCard.addView(brandSpinner, lp(-1,48));
        addGap(deviceCard, 6);
        deviceCard.addView(text("Modelo", 12, MUTED, true));
        modelSpinner = spinner(modelsFor("Samsung"));
        deviceCard.addView(modelSpinner, lp(-1,48));
        brandSpinner.setOnItemSelectedListener(new SimpleItemListener(() -> {
            String brand = (String) brandSpinner.getSelectedItem();
            modelSpinner.setAdapter(adapter(modelsFor(brand)));
            modelSpinner.setSelection(0);
        }));

        addGap(root, 16);
        root.addView(heading("02  •  PERSONALIZE A GERAÇÃO"));
        LinearLayout options = column();
        options.setPadding(dp(14), dp(8), dp(14), dp(12));
        options.setBackground(bg(PANEL, 18, Color.rgb(60,54,72)));
        root.addView(options, lp(-1,-2));
        options.addView(text("Estilo de jogo", 12, MUTED, true));
        styleSpinner = spinner(new String[]{"Capa rápida","Equilibrada","Mira precisa"});
        options.addView(styleSpinner, lp(-1,48));
        options.addView(text("Escala do jogo", 12, MUTED, true));
        scaleSpinner = spinner(new String[]{"0–200","0–100"});
        options.addView(scaleSpinner, lp(-1,48));
        options.addView(text("DPI", 12, MUTED, true));
        dpiSpinner = spinner(new String[]{"DPI personalizado","DPI padrão"});
        options.addView(dpiSpinner, lp(-1,48));

        addGap(root, 16);
        LinearLayout sensiHead = row();
        sensiHead.addView(heading("03  •  SENSIBILIDADES"), new LinearLayout.LayoutParams(0, dp(40), 1));
        TextView range = text("0 — 200", 12, RED, true);
        sensiHead.addView(range);
        root.addView(sensiHead);
        valueList = column();
        root.addView(valueList, lp(-1,-2));
        buildSliders();

        addGap(root, 14);
        profileText = text("Perfil: Samsung Galaxy A05 • Capa rápida", 12, MUTED, false);
        root.addView(profileText);
        addGap(root, 12);

        Button generate = button("✦   GERAR MINHA SENSI", RED, WHITE);
        root.addView(generate, lp(-1,52));
        generate.setOnClickListener(v -> generateValues());

        addGap(root, 10);
        LinearLayout actions = row();
        Button copy = button("COPIAR VALORES", Color.rgb(48,43,59), WHITE);
        Button reset = button("RESTAURAR", Color.rgb(48,43,59), WHITE);
        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, dp(48), 1);
        half.setMargins(0,0,dp(5),0);
        actions.addView(copy, half);
        LinearLayout.LayoutParams half2 = new LinearLayout.LayoutParams(0, dp(48), 1);
        half2.setMargins(dp(5),0,0,0);
        actions.addView(reset, half2);
        root.addView(actions);
        copy.setOnClickListener(v -> copyValues());
        reset.setOnClickListener(v -> {
            System.arraycopy(defaults,0,values,0,values.length);
            scaleSpinner.setSelection(0);
            buildSliders();
            Toast.makeText(this, "Valores restaurados", Toast.LENGTH_SHORT).show();
        });

        addGap(root, 18);
        LinearLayout note = column();
        note.setPadding(dp(14), dp(12), dp(14), dp(12));
        note.setBackground(bg(Color.rgb(26,25,35), 14, Color.rgb(60,54,72)));
        note.addView(text("DICA DE TESTE", 12, RED, true));
        addGap(note, 5);
        note.addView(text("Teste no campo de treinamento. Se a mira passar do alvo, reduza a Geral em 5 pontos; se ficar curta, aumente 5. Ajuste uma opção por vez.", 12, MUTED, false));
        root.addView(note, lp(-1,-2));
        addGap(root, 14);
        TextView disclaimer = text("Este app apenas sugere configurações. Não altera o Free Fire automaticamente e não garante resultados específicos.", 11, MUTED, false);
        disclaimer.setGravity(Gravity.CENTER);
        root.addView(disclaimer, lp(-1,-2));
    }

    private String[] modelsFor(String brand) {
        if (brand.equals("Samsung")) return new String[]{"Galaxy A05","Galaxy A06","Galaxy A15","Galaxy A16","Galaxy A25","Galaxy A35","Galaxy A55","Galaxy S24","Galaxy S25","Outro modelo"};
        if (brand.equals("Motorola")) return new String[]{"Moto E13","Moto G04","Moto G24","Moto G34","Moto G54","Moto G84","Edge 50","Outro modelo"};
        if (brand.equals("Xiaomi / Redmi / POCO")) return new String[]{"Redmi 12","Redmi 13C","Redmi Note 13","Redmi Note 14","POCO C65","POCO X6","Outro modelo"};
        if (brand.equals("Apple iPhone")) return new String[]{"iPhone 11","iPhone 12","iPhone 13","iPhone 14","iPhone 15","iPhone 16","Outro modelo"};
        if (brand.equals("Realme")) return new String[]{"Realme C53","Realme C55","Realme C61","Realme C67","Realme 12","Outro modelo"};
        if (brand.equals("OPPO")) return new String[]{"A38","A58","A60","Reno 11","Outro modelo"};
        if (brand.equals("Vivo")) return new String[]{"Y17s","Y27","Y36","V30","Outro modelo"};
        return new String[]{"Digite/selecionar outro modelo","Outro modelo"};
    }

    private ArrayAdapter<String> adapter(String[] entries) {
        ArrayAdapter<String> a = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, entries);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        return a;
    }

    private Spinner spinner(String[] entries) {
        Spinner s = new Spinner(this);
        s.setAdapter(adapter(entries));
        s.setBackgroundTintList(android.content.res.ColorStateList.valueOf(RED));
        return s;
    }

    private Button button(String label, int color, int textColor) {
        Button b = new Button(this);
        b.setText(label); b.setTextColor(textColor); b.setTextSize(12);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setAllCaps(false);
        b.setBackground(bg(color, 14, color == RED ? RED : Color.rgb(70,64,83)));
        return b;
    }

    private void buildSliders() {
        valueList.removeAllViews();
        for (int i=0; i<labels.length; i++) {
            final int index = i;
            LinearLayout card = column();
            card.setPadding(dp(14), dp(10), dp(14), dp(10));
            card.setBackground(bg(PANEL, 16, Color.rgb(60,54,72)));
            LinearLayout.LayoutParams cardLp = lp(-1,-2);
            cardLp.bottomMargin = dp(8);
            valueList.addView(card, cardLp);
            LinearLayout line = row();
            line.addView(text(labels[i], 14, WHITE, true), new LinearLayout.LayoutParams(0, dp(28), 1));
            TextView number = text(String.valueOf(values[i]), 16, RED, true);
            number.setGravity(Gravity.CENTER);
            line.addView(number, lp(44,28));
            card.addView(line);
            SeekBar seek = new SeekBar(this);
            seek.setMax(200);
            seek.setProgress(values[i]);
            seek.setProgressTintList(android.content.res.ColorStateList.valueOf(RED));
            seek.setThumbTintList(android.content.res.ColorStateList.valueOf(RED));
            seek.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(80,74,92)));
            card.addView(seek, lp(-1,34));
            seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                    values[index] = progress;
                    number.setText(String.valueOf(progress));
                }
                public void onStartTrackingTouch(SeekBar s) {}
                public void onStopTrackingTouch(SeekBar s) {}
            });
        }
    }

    private void generateValues() {
        String style = (String) styleSpinner.getSelectedItem();
        int scaleMax = scaleSpinner.getSelectedItemPosition() == 1 ? 100 : 200;
        int[] base;
        if (style.equals("Capa rápida")) base = new int[]{185,178,168,150,85,140};
        else if (style.equals("Equilibrada")) base = new int[]{165,155,145,130,75,125};
        else base = new int[]{145,135,125,110,65,110};

        // Small deterministic profile adjustment based on chosen device; all values remain suggestions.
        String model = (String) modelSpinner.getSelectedItem();
        int tweak = model.contains("A05") || model.contains("C55") ? 0 : model.contains("iPhone") ? -5 : 3;
        for (int i=0;i<values.length;i++) {
            int v = Math.max(0, Math.min(200, base[i] + tweak));
            if (scaleMax == 100) v = Math.round(v / 2.0f);
            values[i] = v;
        }
        buildSliders();
        profileText.setText("Perfil: " + brandSpinner.getSelectedItem() + " " + model + " • " + style);
        Toast.makeText(this, "Sugestão gerada! Teste e ajuste no jogo.", Toast.LENGTH_SHORT).show();
    }

    private void copyValues() {
        StringBuilder b = new StringBuilder();
        b.append("SENSI GENERATOR\\n");
        b.append(brandSpinner.getSelectedItem()).append(" ").append(modelSpinner.getSelectedItem()).append("\\n");
        b.append("Estilo: ").append(styleSpinner.getSelectedItem()).append("\\n");
        b.append("Escala: ").append(scaleSpinner.getSelectedItem()).append("\\n\\n");
        for (int i=0;i<labels.length;i++) b.append(labels[i]).append(": ").append(values[i]).append("\\n");
        ClipboardManager cm = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("Sensi Generator", b.toString()));
        Toast.makeText(this, "Configuração copiada", Toast.LENGTH_SHORT).show();
    }

    private static class SimpleItemListener implements android.widget.AdapterView.OnItemSelectedListener {
        private final Runnable action;
        SimpleItemListener(Runnable r) { action = r; }
        public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) { action.run(); }
        public void onNothingSelected(android.widget.AdapterView<?> parent) {}
    }
}

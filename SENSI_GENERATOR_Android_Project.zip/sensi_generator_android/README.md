# SENSI GENERATOR — projeto Android

Projeto Android nativo em Java para gerar configurações demonstrativas de sensibilidade do Free Fire.

## Recursos
- Seleção de marca e modelo de celular
- Estilos: Capa rápida, Equilibrada e Mira precisa
- Escala 0–200 ou 0–100
- Sliders ajustáveis para Geral, Ponto Vermelho, Mira 2x, Mira 4x, Mira AWM e Olhadinha
- Gerar, copiar e restaurar valores
- Interface vertical adaptada a telas de celular
- Sem permissões de rede e sem modificar o jogo

## Como gerar o APK
O arquivo APK não foi compilado neste ambiente. Para gerar:
1. Instale o Android Studio em um computador.
2. Abra a pasta `sensi_generator_android` pelo Android Studio.
3. Aguarde a sincronização do Gradle e instale um Android SDK compatível (API 35).
4. No menu **Build**, selecione **Build APK(s)**.
5. O APK de depuração ficará em `app/build/outputs/apk/debug/app-debug.apk`.

Também é possível executar `./gradlew assembleDebug` se você tiver o Gradle Wrapper instalado/configurado. Este ZIP não inclui o wrapper porque ele deve ser gerado pelo Android Studio.

## Observação
Este app é um gerador de recomendações, não um cheat. Os valores são sugestões para testar manualmente nas configurações do jogo e não garantem desempenho ou capa automática.
